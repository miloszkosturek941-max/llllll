create extension if not exists pgcrypto;

do $$
begin
  create type public.user_role as enum ('user', 'admin');
exception
  when duplicate_object then null;
end
$$;

create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text not null unique check (username ~ '^[a-z0-9_]{3,24}$'),
  display_name text not null check (char_length(display_name) between 2 and 40),
  avatar_url text,
  bio text not null default '' check (char_length(bio) <= 160),
  is_verified boolean not null default false,
  role public.user_role not null default 'user',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  drive_url text not null,
  drive_file_id text,
  caption text not null default '' check (char_length(caption) <= 150),
  description text not null default '' check (char_length(description) <= 500),
  like_count integer not null default 0 check (like_count >= 0),
  comment_count integer not null default 0 check (comment_count >= 0),
  repost_count integer not null default 0 check (repost_count >= 0),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles (id) on delete cascade,
  video_id uuid not null references public.videos (id) on delete cascade,
  created_at timestamptz not null default timezone('utc', now()),
  primary key (user_id, video_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  video_id uuid not null references public.videos (id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 300),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.reposts (
  user_id uuid not null references public.profiles (id) on delete cascade,
  video_id uuid not null references public.videos (id) on delete cascade,
  created_at timestamptz not null default timezone('utc', now()),
  primary key (user_id, video_id)
);

create index if not exists idx_profiles_role on public.profiles (role);
create index if not exists idx_videos_user_id_created_at on public.videos (user_id, created_at desc);
create index if not exists idx_videos_created_at on public.videos (created_at desc);
create index if not exists idx_likes_video_id on public.likes (video_id);
create index if not exists idx_comments_video_id_created_at on public.comments (video_id, created_at desc);
create index if not exists idx_reposts_video_id on public.reposts (video_id);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := timezone('utc', now());
  return new;
end;
$$;

create or replace function public.normalize_username(input text)
returns text
language sql
immutable
as $$
  select coalesce(
    nullif(
      regexp_replace(lower(trim(coalesce(input, ''))), '[^a-z0-9_]+', '', 'g'),
      ''
    ),
    'gracz'
  );
$$;

create or replace function public.make_unique_username(base text)
returns text
language plpgsql
as $$
declare
  normalized text := public.normalize_username(base);
  candidate text := normalized;
  suffix integer := 0;
begin
  while exists (select 1 from public.profiles where username = candidate) loop
    suffix := suffix + 1;
    candidate :=
      left(normalized, greatest(3, 24 - length(suffix::text) - 1))
      || '_'
      || suffix::text;
  end loop;

  return candidate;
end;
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
as $$
  select exists (
    select 1
    from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_username text;
  resolved_display_name text;
  assigned_role public.user_role;
begin
  requested_username := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'username'), ''),
    split_part(coalesce(new.email, ''), '@', 1),
    'gracz'
  );

  resolved_display_name := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''),
    split_part(coalesce(new.email, ''), '@', 1),
    'Kibic'
  );

  assigned_role :=
    case
      when lower(coalesce(new.email, '')) = 'admin@strefagola.pl' then 'admin'::public.user_role
      else 'user'::public.user_role
    end;

  insert into public.profiles (
    id,
    username,
    display_name,
    role,
    is_verified
  )
  values (
    new.id,
    public.make_unique_username(requested_username),
    left(resolved_display_name, 40),
    assigned_role,
    assigned_role = 'admin'
  );

  return new;
end;
$$;

create or replace function public.protect_profile_fields()
returns trigger
language plpgsql
as $$
begin
  new.id := old.id;
  new.created_at := old.created_at;

  if not public.is_admin() and (new.role is distinct from old.role or new.is_verified is distinct from old.is_verified) then
    raise exception 'Tylko administrator może zmienić rolę lub weryfikację.';
  end if;

  return new;
end;
$$;

create or replace function public.sync_video_counters()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  target_video_id uuid := coalesce(new.video_id, old.video_id);
begin
  if tg_table_name = 'likes' then
    update public.videos
    set like_count = (select count(*) from public.likes where video_id = target_video_id)
    where id = target_video_id;
  elsif tg_table_name = 'comments' then
    update public.videos
    set comment_count = (select count(*) from public.comments where video_id = target_video_id)
    where id = target_video_id;
  elsif tg_table_name = 'reposts' then
    update public.videos
    set repost_count = (select count(*) from public.reposts where video_id = target_video_id)
    where id = target_video_id;
  end if;

  return null;
end;
$$;

drop trigger if exists on_profiles_updated on public.profiles;
create trigger on_profiles_updated
before update on public.profiles
for each row
execute function public.set_updated_at();

drop trigger if exists guard_profiles on public.profiles;
create trigger guard_profiles
before update on public.profiles
for each row
execute function public.protect_profile_fields();

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row
execute function public.handle_new_user();

drop trigger if exists sync_likes_count on public.likes;
create trigger sync_likes_count
after insert or delete on public.likes
for each row
execute function public.sync_video_counters();

drop trigger if exists sync_comments_count on public.comments;
create trigger sync_comments_count
after insert or delete on public.comments
for each row
execute function public.sync_video_counters();

drop trigger if exists sync_reposts_count on public.reposts;
create trigger sync_reposts_count
after insert or delete on public.reposts
for each row
execute function public.sync_video_counters();

alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.reposts enable row level security;

drop policy if exists "profiles_public_read" on public.profiles;
create policy "profiles_public_read"
on public.profiles
for select
to anon, authenticated
using (true);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
on public.profiles
for insert
to authenticated
with check ((select auth.uid()) = id);

drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin"
on public.profiles
for update
to authenticated
using ((select auth.uid()) = id or public.is_admin())
with check ((select auth.uid()) = id or public.is_admin());

drop policy if exists "videos_public_read" on public.videos;
create policy "videos_public_read"
on public.videos
for select
to anon, authenticated
using (true);

drop policy if exists "videos_insert_own" on public.videos;
create policy "videos_insert_own"
on public.videos
for insert
to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "videos_delete_own_or_admin" on public.videos;
create policy "videos_delete_own_or_admin"
on public.videos
for delete
to authenticated
using ((select auth.uid()) = user_id or public.is_admin());

drop policy if exists "likes_select_own" on public.likes;
create policy "likes_select_own"
on public.likes
for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "likes_insert_own" on public.likes;
create policy "likes_insert_own"
on public.likes
for insert
to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "likes_delete_own" on public.likes;
create policy "likes_delete_own"
on public.likes
for delete
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "comments_public_read" on public.comments;
create policy "comments_public_read"
on public.comments
for select
to anon, authenticated
using (true);

drop policy if exists "comments_insert_own" on public.comments;
create policy "comments_insert_own"
on public.comments
for insert
to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "comments_delete_own_or_admin" on public.comments;
create policy "comments_delete_own_or_admin"
on public.comments
for delete
to authenticated
using ((select auth.uid()) = user_id or public.is_admin());

drop policy if exists "reposts_select_own" on public.reposts;
create policy "reposts_select_own"
on public.reposts
for select
to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "reposts_insert_own" on public.reposts;
create policy "reposts_insert_own"
on public.reposts
for insert
to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "reposts_delete_own" on public.reposts;
create policy "reposts_delete_own"
on public.reposts
for delete
to authenticated
using ((select auth.uid()) = user_id);
