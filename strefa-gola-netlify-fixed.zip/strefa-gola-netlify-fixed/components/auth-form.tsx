'use client'

import { FormEvent, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'

import { createClient } from '@/lib/supabase/client'

const initialState = {
  email: '',
  password: '',
  username: '',
  displayName: '',
}

export function AuthForm() {
  const router = useRouter()
  const supabase = useMemo(() => createClient(), [])

  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [form, setForm] = useState(initialState)
  const [pending, setPending] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setPending(true)
    setMessage(null)
    setError(null)

    if (mode === 'signup') {
      const { error: signUpError, data } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: {
          data: {
            username: form.username,
            display_name: form.displayName,
          },
        },
      })

      if (signUpError) {
        setError(signUpError.message)
        setPending(false)
        return
      }

      if (data.session) {
        router.push('/')
        router.refresh()
      } else {
        setMessage('Konto utworzone. Jeśli masz włączone potwierdzenie e-mail w Supabase, sprawdź skrzynkę i aktywuj konto.')
      }

      setPending(false)
      return
    }

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: form.email,
      password: form.password,
    })

    if (signInError) {
      setError(signInError.message)
      setPending(false)
      return
    }

    router.push('/')
    router.refresh()
    setPending(false)
  }

  return (
    <div className="auth-card">
      <div className="auth-switcher" role="tablist" aria-label="Wybór formularza logowania lub rejestracji">
        <button
          type="button"
          className={mode === 'login' ? 'auth-switcher__tab auth-switcher__tab--active' : 'auth-switcher__tab'}
          onClick={() => setMode('login')}
        >
          Logowanie
        </button>
        <button
          type="button"
          className={mode === 'signup' ? 'auth-switcher__tab auth-switcher__tab--active' : 'auth-switcher__tab'}
          onClick={() => setMode('signup')}
        >
          Rejestracja
        </button>
      </div>

      <form className="form-stack" onSubmit={handleSubmit}>
        <label className="field">
          <span>Email</span>
          <input
            required
            type="email"
            value={form.email}
            onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))}
            placeholder="twoj@email.pl"
          />
        </label>

        <label className="field">
          <span>Hasło</span>
          <input
            required
            minLength={6}
            type="password"
            value={form.password}
            onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))}
            placeholder="Minimum 6 znaków"
          />
        </label>

        {mode === 'signup' ? (
          <>
            <label className="field">
              <span>Nazwa użytkownika</span>
              <input
                required
                minLength={3}
                maxLength={24}
                value={form.username}
                onChange={(event) => setForm((current) => ({ ...current, username: event.target.value }))}
                placeholder="np. strefa_kibica"
              />
            </label>

            <label className="field">
              <span>Wyświetlana nazwa</span>
              <input
                required
                minLength={2}
                maxLength={40}
                value={form.displayName}
                onChange={(event) => setForm((current) => ({ ...current, displayName: event.target.value }))}
                placeholder="Jak chcesz się pokazywać w aplikacji"
              />
            </label>
          </>
        ) : null}

        <button type="submit" className="primary-button primary-button--wide" disabled={pending}>
          {pending ? 'Chwila...' : mode === 'login' ? 'Wejdź do Strefy Gola' : 'Załóż konto'}
        </button>

        {message ? <p className="form-message form-message--success">{message}</p> : null}
        {error ? <p className="form-message form-message--error">{error}</p> : null}
      </form>
    </div>
  )
}
