'use client'

import { useMemo, useState } from 'react'
import { ShieldCheck, Trash2 } from 'lucide-react'

import { createClient } from '@/lib/supabase/client'
import type { Profile, VideoWithAuthor } from '@/lib/types'
import { formatRelativeTime } from '@/lib/utils'

interface AdminDashboardProps {
  profiles: Profile[]
  videos: VideoWithAuthor[]
}

export function AdminDashboard({ profiles: initialProfiles, videos: initialVideos }: AdminDashboardProps) {
  const supabase = useMemo(() => createClient(), [])
  const [profiles, setProfiles] = useState(initialProfiles)
  const [videos, setVideos] = useState(initialVideos)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const toggleVerification = async (profile: Profile) => {
    setMessage(null)
    setError(null)

    const { error: updateError } = await supabase
      .from('profiles')
      .update({ is_verified: !profile.is_verified })
      .eq('id', profile.id)

    if (updateError) {
      setError(updateError.message)
      return
    }

    setProfiles((current) =>
      current.map((item) =>
        item.id === profile.id ? { ...item, is_verified: !item.is_verified } : item,
      ),
    )

    setMessage(`Zmieniono status weryfikacji dla @${profile.username}.`)
  }

  const deleteVideo = async (video: VideoWithAuthor) => {
    setMessage(null)
    setError(null)

    if (!window.confirm(`Usunąć film „${video.caption}”?`)) {
      return
    }

    const { error: deleteError } = await supabase.from('videos').delete().eq('id', video.id)

    if (deleteError) {
      setError(deleteError.message)
      return
    }

    setVideos((current) => current.filter((item) => item.id !== video.id))
    setMessage('Film został usunięty.')
  }

  return (
    <div className="admin-grid">
      <section className="panel">
        <div className="panel__header">
          <div>
            <p className="panel__eyebrow">Moderacja użytkowników</p>
            <h2>Weryfikacja kont</h2>
          </div>
          <span className="info-chip">{profiles.length} użytkowników</span>
        </div>

        <div className="table-list">
          {profiles.map((profile) => (
            <article key={profile.id} className="table-row">
              <div>
                <strong>{profile.display_name}</strong>
                <p className="muted-text">@{profile.username} • {profile.role}</p>
              </div>
              <button type="button" className="ghost-button" onClick={() => toggleVerification(profile)}>
                <ShieldCheck size={16} />
                {profile.is_verified ? 'Cofnij weryfikację' : 'Nadaj weryfikację'}
              </button>
            </article>
          ))}
        </div>
      </section>

      <section className="panel">
        <div className="panel__header">
          <div>
            <p className="panel__eyebrow">Moderacja treści</p>
            <h2>Usuwanie filmów</h2>
          </div>
          <span className="info-chip">{videos.length} filmów</span>
        </div>

        <div className="table-list">
          {videos.map((video) => (
            <article key={video.id} className="table-row table-row--stackOnMobile">
              <div>
                <strong>{video.caption || 'Bez opisu'}</strong>
                <p className="muted-text">
                  @{video.author?.username ?? 'nieznany'} • {formatRelativeTime(video.created_at)}
                </p>
              </div>
              <button type="button" className="ghost-button ghost-button--danger" onClick={() => deleteVideo(video)}>
                <Trash2 size={16} />
                Usuń film
              </button>
            </article>
          ))}
        </div>
      </section>

      {message ? <p className="form-message form-message--success">{message}</p> : null}
      {error ? <p className="form-message form-message--error">{error}</p> : null}
    </div>
  )
}
