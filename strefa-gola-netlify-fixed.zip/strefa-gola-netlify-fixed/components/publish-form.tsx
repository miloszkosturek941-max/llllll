'use client'

import { FormEvent, useMemo, useState } from 'react'
import { useRouter } from 'next/navigation'

import { extractGoogleDriveFileId } from '@/lib/google-drive'
import { createClient } from '@/lib/supabase/client'

interface PublishFormProps {
  userId: string
}

export function PublishForm({ userId }: PublishFormProps) {
  const router = useRouter()
  const supabase = useMemo(() => createClient(), [])

  const [driveUrl, setDriveUrl] = useState('')
  const [caption, setCaption] = useState('')
  const [description, setDescription] = useState('')
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fileId = extractGoogleDriveFileId(driveUrl)

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setPending(true)
    setError(null)

    const resolvedFileId = extractGoogleDriveFileId(driveUrl)

    if (!resolvedFileId) {
      setError('Wklej pełny link do pliku Google Drive, np. https://drive.google.com/file/d/FILE_ID/view?usp=sharing')
      setPending(false)
      return
    }

    const { error: insertError } = await supabase.from('videos').insert({
      user_id: userId,
      drive_url: driveUrl.trim(),
      drive_file_id: resolvedFileId,
      caption: caption.trim(),
      description: description.trim(),
    })

    if (insertError) {
      setError(insertError.message)
      setPending(false)
      return
    }

    router.push('/')
    router.refresh()
  }

  return (
    <form className="panel panel--form" onSubmit={handleSubmit}>
      <div>
        <p className="panel__eyebrow">Publikacja z Google Drive</p>
        <h2>Dodaj nowy klip</h2>
        <p className="muted-text">
          Wklej link do filmu z Dysku Google. Plik musi mieć ustawienie <strong>Anyone with the link</strong> oraz rolę <strong>Viewer</strong>.
        </p>
      </div>

      <label className="field">
        <span>Link do filmu</span>
        <input
          required
          type="url"
          value={driveUrl}
          onChange={(event) => setDriveUrl(event.target.value)}
          placeholder="https://drive.google.com/file/d/FILE_ID/view?usp=sharing"
        />
      </label>

      <label className="field">
        <span>Krótki opis / caption</span>
        <input
          required
          maxLength={150}
          value={caption}
          onChange={(event) => setCaption(event.target.value)}
          placeholder="Np. Gol życia w 89 minucie"
        />
      </label>

      <label className="field">
        <span>Opis dodatkowy</span>
        <textarea
          value={description}
          maxLength={500}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="Dodaj trochę kontekstu, #hashtagi albo źródło meczu"
        />
      </label>

      <div className="info-chip-row">
        <span className="info-chip">Wykryty plik: {fileId ?? 'brak'}</span>
        <span className="info-chip">Limit opisu: 500 znaków</span>
      </div>

      <button type="submit" className="primary-button primary-button--wide" disabled={pending}>
        {pending ? 'Publikuję...' : 'Opublikuj film'}
      </button>

      {error ? <p className="form-message form-message--error">{error}</p> : null}
    </form>
  )
}
