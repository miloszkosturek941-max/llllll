import Image from 'next/image'
import Link from 'next/link'

import type { Profile } from '@/lib/types'

import { AuthControls } from '@/components/auth-controls'

interface SiteHeaderProps {
  profile: Profile | null
}

export function SiteHeader({ profile }: SiteHeaderProps) {
  return (
    <header className="site-header">
      <div className="site-header__inner">
        <Link href="/" className="brand" aria-label="Przejdź do strony głównej Strefa Gola">
          <div className="brand__logoWrap">
            <Image src="/logo.png" alt="Strefa Gola" width={52} height={52} priority />
          </div>
          <div>
            <span className="brand__eyebrow">short video football app</span>
            <strong className="brand__title">Strefa Gola</strong>
          </div>
        </Link>

        <nav className="site-nav" aria-label="Główna nawigacja">
          <Link href="/" className="ghost-button">
            Feed
          </Link>
          <Link href="/publish" className="ghost-button">
            Dodaj film
          </Link>
          {profile ? (
            <>
              <Link href={`/profile/${profile.username}`} className="ghost-button">
                Mój profil
              </Link>
              {profile.role === 'admin' ? (
                <Link href="/admin" className="ghost-button ghost-button--accent">
                  Admin
                </Link>
              ) : null}
            </>
          ) : null}
          <AuthControls profile={profile} />
        </nav>
      </div>
    </header>
  )
}
