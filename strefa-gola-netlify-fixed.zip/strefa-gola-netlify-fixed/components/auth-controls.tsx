'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

import { createClient } from '@/lib/supabase/client'
import type { Profile } from '@/lib/types'

interface AuthControlsProps {
  profile: Profile | null
}

export function AuthControls({ profile }: AuthControlsProps) {
  const router = useRouter()
  const [pending, setPending] = useState(false)

  const handleSignOut = async () => {
    const supabase = createClient()
    setPending(true)
    await supabase.auth.signOut()
    router.push('/')
    router.refresh()
    setPending(false)
  }

  if (!profile) {
    return (
      <Link href="/auth" className="primary-button">
        Zaloguj się
      </Link>
    )
  }

  return (
    <button type="button" className="primary-button primary-button--dark" onClick={handleSignOut} disabled={pending}>
      {pending ? 'Wylogowywanie...' : `Wyloguj (@${profile.username})`}
    </button>
  )
}
