'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  type FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import {
  BadgeCheck,
  Heart,
  MessageCircle,
  Play,
  Repeat2,
  Volume2,
  VolumeX,
} from 'lucide-react'

import { resolveGoogleDriveAsset } from '@/lib/google-drive'
import { createClient } from '@/lib/supabase/client'
import type { CommentWithAuthor, VideoWithAuthor } from '@/lib/types'
import { formatCount, formatRelativeTime } from '@/lib/utils'

interface VideoCardProps {
  video: VideoWithAuthor
  viewerId: string | null
}

export function VideoCard({ video, viewerId }: VideoCardProps) {
  const router = useRouter()
  const supabase = useMemo(() => createClient(), [])
  const driveAsset = useMemo(
    () => resolveGoogleDriveAsset(video.drive_url, video.drive_file_id),
    [video.drive_file_id, video.drive_url],
  )

  const videoRef = useRef<HTMLVideoElement | null>(null)

  const [playerMode, setPlayerMode] = useState<'video' | 'iframe'>(driveAsset.fileId ? 'video' : 'iframe')
  const [muted, setMuted] = useState(true)
  const [paused, setPaused] = useState(false)
  const [likes, setLikes] = useState(video.like_count)
  const [reposts, setReposts] = useState(video.repost_count)
  const [commentsCount, setCommentsCount] = useState(video.comment_count)
  const [isLiked, setIsLiked] = useState(false)
  const [isReposted, setIsReposted] = useState(false)
  const [showComments, setShowComments] = useState(false)
  const [commentText, setCommentText] = useState('')
  const [comments, setComments] = useState<CommentWithAuthor[]>([])
  const [loadingComments, setLoadingComments] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [commentError, setCommentError] = useState<string | null>(null)
  const [submittingComment, setSubmittingComment] = useState(false)

  useEffect(() => {
    if (playerMode !== 'video' || !videoRef.current) {
      return
    }

    const currentVideo = videoRef.current
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0]
        if (!entry) {
          return
        }

        if (entry.isIntersecting) {
          currentVideo.play().then(() => setPaused(false)).catch(() => {
            setPaused(true)
          })
        } else {
          currentVideo.pause()
          setPaused(true)
        }
      },
      { threshold: 0.65 },
    )

    observer.observe(currentVideo)

    return () => {
      observer.disconnect()
    }
  }, [playerMode])

  useEffect(() => {
    let cancelled = false

    if (!viewerId) {
      setIsLiked(false)
      setIsReposted(false)
      return
    }

    const loadInteractions = async () => {
      const [{ data: like }, { data: repost }] = await Promise.all([
        supabase
          .from('likes')
          .select('video_id')
          .eq('video_id', video.id)
          .eq('user_id', viewerId)
          .maybeSingle(),
        supabase
          .from('reposts')
          .select('video_id')
          .eq('video_id', video.id)
          .eq('user_id', viewerId)
          .maybeSingle(),
      ])

      if (cancelled) {
        return
      }

      setIsLiked(Boolean(like))
      setIsReposted(Boolean(repost))
    }

    void loadInteractions()

    return () => {
      cancelled = true
    }
  }, [supabase, video.id, viewerId])

  const loadComments = useCallback(async () => {
    setLoadingComments(true)
    setCommentError(null)

    const { data: commentRows, error: commentsQueryError } = await supabase
      .from('comments')
      .select('*')
      .eq('video_id', video.id)
      .order('created_at', { ascending: false })
      .limit(50)

    if (commentsQueryError) {
      setCommentError(commentsQueryError.message)
      setLoadingComments(false)
      return
    }

    const profileIds = Array.from(new Set((commentRows ?? []).map((item) => item.user_id)))

    const profilesResult = profileIds.length
      ? await supabase
          .from('profiles')
          .select('id, username, display_name, avatar_url, is_verified')
          .in('id', profileIds)
      : { data: [], error: null }

    if (profilesResult.error) {
      setCommentError(profilesResult.error.message)
      setLoadingComments(false)
      return
    }

    const profileMap = new Map((profilesResult.data ?? []).map((item) => [item.id, item]))

    setComments(
      (commentRows ?? []).map((item) => ({
        ...item,
        author: profileMap.get(item.user_id) ?? null,
      })),
    )

    setLoadingComments(false)
  }, [supabase, video.id])

  useEffect(() => {
    if (showComments && comments.length === 0) {
      void loadComments()
    }
  }, [comments.length, loadComments, showComments])

  const ensureAuthenticated = () => {
    if (viewerId) {
      return true
    }

    router.push('/auth')
    return false
  }

  const togglePlayback = () => {
    if (!videoRef.current || playerMode !== 'video') {
      return
    }

    if (videoRef.current.paused) {
      videoRef.current.play().catch(() => {
        setPaused(true)
      })
      setPaused(false)
      return
    }

    videoRef.current.pause()
    setPaused(true)
  }

  const toggleLike = async () => {
    if (!ensureAuthenticated()) {
      return
    }

    setActionError(null)

    if (isLiked) {
      const { error } = await supabase
        .from('likes')
        .delete()
        .eq('video_id', video.id)
        .eq('user_id', viewerId!)

      if (error) {
        setActionError(error.message)
        return
      }

      setIsLiked(false)
      setLikes((current) => Math.max(0, current - 1))
      return
    }

    const { error } = await supabase.from('likes').insert({
      video_id: video.id,
      user_id: viewerId!,
    })

    if (error) {
      setActionError(error.message)
      return
    }

    setIsLiked(true)
    setLikes((current) => current + 1)
  }

  const toggleRepost = async () => {
    if (!ensureAuthenticated()) {
      return
    }

    setActionError(null)

    if (isReposted) {
      const { error } = await supabase
        .from('reposts')
        .delete()
        .eq('video_id', video.id)
        .eq('user_id', viewerId!)

      if (error) {
        setActionError(error.message)
        return
      }

      setIsReposted(false)
      setReposts((current) => Math.max(0, current - 1))
      return
    }

    const { error } = await supabase.from('reposts').insert({
      video_id: video.id,
      user_id: viewerId!,
    })

    if (error) {
      setActionError(error.message)
      return
    }

    setIsReposted(true)
    setReposts((current) => current + 1)
  }

  const handleCommentSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()

    if (!ensureAuthenticated()) {
      return
    }

    if (!commentText.trim()) {
      return
    }

    setCommentError(null)
    setSubmittingComment(true)

    const { error } = await supabase.from('comments').insert({
      video_id: video.id,
      user_id: viewerId!,
      body: commentText.trim(),
    })

    if (error) {
      setCommentError(error.message)
      setSubmittingComment(false)
      return
    }

    setCommentText('')
    setCommentsCount((current) => current + 1)
    await loadComments()
    setShowComments(true)
    setSubmittingComment(false)
  }

  return (
    <article className="video-card">
      <div className="video-card__mediaWrap">
        {playerMode === 'video' ? (
          <>
            <video
              ref={videoRef}
              className="video-card__media"
              src={driveAsset.videoUrl}
              autoPlay
              loop
              muted={muted}
              playsInline
              preload="metadata"
              onError={() => setPlayerMode('iframe')}
              onClick={togglePlayback}
            />
            <div className="video-card__overlayControls">
              <button type="button" className="overlay-button" onClick={togglePlayback}>
                <Play size={18} />
                {paused ? 'Odtwórz' : 'Pauza'}
              </button>
              <button type="button" className="overlay-button" onClick={() => setMuted((current) => !current)}>
                {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                {muted ? 'Włącz dźwięk' : 'Wycisz'}
              </button>
            </div>
          </>
        ) : (
          <iframe
            className="video-card__media"
            src={driveAsset.previewUrl}
            title={video.caption || 'Film w Strefa Gola'}
            allow="autoplay; fullscreen"
            allowFullScreen
          />
        )}
      </div>

      <div className="video-card__content">
        <div className="video-card__metaTop">
          <div>
            <div className="video-card__authorRow">
              <Link href={video.author ? `/profile/${video.author.username}` : '#'} className="video-card__authorName">
                {video.author?.display_name ?? 'Nieznany autor'}
              </Link>
              {video.author?.is_verified ? <BadgeCheck className="verified-icon" size={18} /> : null}
            </div>
            <p className="muted-text">
              @{video.author?.username ?? 'brak'} • {formatRelativeTime(video.created_at)}
            </p>
          </div>
          <span className="info-chip">Google Drive</span>
        </div>

        <div>
          <h2 className="video-card__title">{video.caption || 'Bez opisu'}</h2>
          {video.description ? <p className="video-card__description">{video.description}</p> : null}
        </div>

        <div className="video-card__actions">
          <button
            type="button"
            className={isLiked ? 'metric-button metric-button--active' : 'metric-button'}
            onClick={toggleLike}
            aria-pressed={isLiked}
          >
            <Heart size={18} />
            <span>{formatCount(likes)}</span>
            <small>Lajki</small>
          </button>

          <button
            type="button"
            className={showComments ? 'metric-button metric-button--active' : 'metric-button'}
            onClick={() => setShowComments((current) => !current)}
            aria-pressed={showComments}
          >
            <MessageCircle size={18} />
            <span>{formatCount(commentsCount)}</span>
            <small>Komentarze</small>
          </button>

          <button
            type="button"
            className={isReposted ? 'metric-button metric-button--active' : 'metric-button'}
            onClick={toggleRepost}
            aria-pressed={isReposted}
          >
            <Repeat2 size={18} />
            <span>{formatCount(reposts)}</span>
            <small>Reposty</small>
          </button>
        </div>

        {actionError ? <p className="form-message form-message--error">{actionError}</p> : null}

        <section className="comments-panel">
          <div className="comments-panel__header">
            <strong>Dyskusja</strong>
            <button type="button" className="ghost-button" onClick={() => setShowComments((current) => !current)}>
              {showComments ? 'Zwiń' : 'Rozwiń'}
            </button>
          </div>

          {showComments ? (
            <>
              <form className="comment-form" onSubmit={handleCommentSubmit}>
                <textarea
                  value={commentText}
                  onChange={(event) => setCommentText(event.target.value)}
                  placeholder={viewerId ? 'Dodaj komentarz...' : 'Zaloguj się, aby komentować'}
                  disabled={!viewerId || submittingComment}
                />
                <button type="submit" className="primary-button" disabled={!viewerId || submittingComment}>
                  {submittingComment ? 'Dodawanie...' : 'Skomentuj'}
                </button>
              </form>

              {commentError ? <p className="form-message form-message--error">{commentError}</p> : null}

              <div className="comments-list">
                {loadingComments ? <p className="muted-text">Ładuję komentarze...</p> : null}
                {!loadingComments && comments.length === 0 ? (
                  <p className="muted-text">Na razie cisza. Zostaw pierwszy komentarz.</p>
                ) : null}
                {comments.map((comment) => (
                  <article key={comment.id} className="comment-item">
                    <div className="comment-item__header">
                      <span>
                        <strong>{comment.author?.display_name ?? 'Użytkownik'}</strong>
                        {comment.author?.is_verified ? <BadgeCheck className="verified-icon verified-icon--small" size={14} /> : null}
                      </span>
                      <small>{formatRelativeTime(comment.created_at)}</small>
                    </div>
                    <p>@{comment.author?.username ?? 'profil'} • {comment.body}</p>
                  </article>
                ))}
              </div>
            </>
          ) : (
            <p className="muted-text">Rozwiń sekcję komentarzy, żeby zobaczyć dyskusję pod klipem.</p>
          )}
        </section>
      </div>
    </article>
  )
}
