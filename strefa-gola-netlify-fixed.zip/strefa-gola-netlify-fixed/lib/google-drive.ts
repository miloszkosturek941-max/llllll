const DRIVE_FILE_PATTERNS = [
  /\/file\/d\/([a-zA-Z0-9_-]+)/,
  /[?&]id=([a-zA-Z0-9_-]+)/,
  /\/uc\?.*id=([a-zA-Z0-9_-]+)/,
  /\/thumbnail\?id=([a-zA-Z0-9_-]+)/,
]

export function extractGoogleDriveFileId(input: string): string | null {
  const value = input.trim()

  for (const pattern of DRIVE_FILE_PATTERNS) {
    const match = value.match(pattern)
    if (match?.[1]) {
      return match[1]
    }
  }

  return null
}

export function buildGoogleDriveVideoUrl(fileId: string): string {
  return `https://drive.google.com/uc?export=download&id=${fileId}`
}

export function buildGoogleDrivePreviewUrl(fileId: string): string {
  return `https://drive.google.com/file/d/${fileId}/preview`
}

export function resolveGoogleDriveAsset(url: string, existingFileId?: string | null) {
  const fileId = existingFileId ?? extractGoogleDriveFileId(url)

  return {
    fileId,
    videoUrl: fileId ? buildGoogleDriveVideoUrl(fileId) : url,
    previewUrl: fileId ? buildGoogleDrivePreviewUrl(fileId) : url,
  }
}
