export function cn(...values: Array<string | false | null | undefined>) {
  return values.filter(Boolean).join(' ')
}

export function formatRelativeTime(value: string) {
  const date = new Date(value)
  const now = new Date()
  const diffMs = date.getTime() - now.getTime()
  const diffAbs = Math.abs(diffMs)
  const formatter = new Intl.RelativeTimeFormat('pl', { numeric: 'auto' })

  const minute = 60_000
  const hour = 60 * minute
  const day = 24 * hour
  const week = 7 * day

  if (diffAbs < hour) {
    return formatter.format(Math.round(diffMs / minute), 'minute')
  }

  if (diffAbs < day) {
    return formatter.format(Math.round(diffMs / hour), 'hour')
  }

  if (diffAbs < week) {
    return formatter.format(Math.round(diffMs / day), 'day')
  }

  return new Intl.DateTimeFormat('pl-PL', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date)
}

export function formatCount(value: number) {
  if (value < 1000) {
    return String(value)
  }

  if (value < 1_000_000) {
    return `${(value / 1000).toFixed(1).replace('.0', '')} tys.`
  }

  return `${(value / 1_000_000).toFixed(1).replace('.0', '')} mln`
}
