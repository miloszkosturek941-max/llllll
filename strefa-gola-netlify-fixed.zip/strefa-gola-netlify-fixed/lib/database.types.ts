export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string
          display_name: string
          avatar_url: string | null
          bio: string
          is_verified: boolean
          role: Database['public']['Enums']['user_role']
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          display_name: string
          avatar_url?: string | null
          bio?: string
          is_verified?: boolean
          role?: Database['public']['Enums']['user_role']
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string
          display_name?: string
          avatar_url?: string | null
          bio?: string
          is_verified?: boolean
          role?: Database['public']['Enums']['user_role']
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      videos: {
        Row: {
          id: string
          user_id: string
          drive_url: string
          drive_file_id: string | null
          caption: string
          description: string
          like_count: number
          comment_count: number
          repost_count: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          drive_url: string
          drive_file_id?: string | null
          caption?: string
          description?: string
          like_count?: number
          comment_count?: number
          repost_count?: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          drive_url?: string
          drive_file_id?: string | null
          caption?: string
          description?: string
          like_count?: number
          comment_count?: number
          repost_count?: number
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'videos_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'profiles'
            referencedColumns: ['id']
          },
        ]
      }
      likes: {
        Row: {
          user_id: string
          video_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          video_id: string
          created_at?: string
        }
        Update: {
          user_id?: string
          video_id?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'likes_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'profiles'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'likes_video_id_fkey'
            columns: ['video_id']
            isOneToOne: false
            referencedRelation: 'videos'
            referencedColumns: ['id']
          },
        ]
      }
      comments: {
        Row: {
          id: string
          user_id: string
          video_id: string
          body: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          video_id: string
          body: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          video_id?: string
          body?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'comments_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'profiles'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'comments_video_id_fkey'
            columns: ['video_id']
            isOneToOne: false
            referencedRelation: 'videos'
            referencedColumns: ['id']
          },
        ]
      }
      reposts: {
        Row: {
          user_id: string
          video_id: string
          created_at: string
        }
        Insert: {
          user_id: string
          video_id: string
          created_at?: string
        }
        Update: {
          user_id?: string
          video_id?: string
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: 'reposts_user_id_fkey'
            columns: ['user_id']
            isOneToOne: false
            referencedRelation: 'profiles'
            referencedColumns: ['id']
          },
          {
            foreignKeyName: 'reposts_video_id_fkey'
            columns: ['video_id']
            isOneToOne: false
            referencedRelation: 'videos'
            referencedColumns: ['id']
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      user_role: 'user' | 'admin'
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
