import type { Database } from '@/lib/database.types'

export type Profile = Database['public']['Tables']['profiles']['Row']
export type Video = Database['public']['Tables']['videos']['Row']
export type Comment = Database['public']['Tables']['comments']['Row']

export interface VideoWithAuthor extends Video {
  author: Profile | null
}

export interface CommentWithAuthor extends Comment {
  author: Pick<Profile, 'id' | 'username' | 'display_name' | 'avatar_url' | 'is_verified'> | null
}
