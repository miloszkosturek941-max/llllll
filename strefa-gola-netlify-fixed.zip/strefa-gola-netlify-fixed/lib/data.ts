import type { User } from '@supabase/supabase-js'

import { createClient } from '@/lib/supabase/server'
import type { Profile, VideoWithAuthor } from '@/lib/types'

async function getProfilesMap(ids: string[]) {
  const uniqueIds = Array.from(new Set(ids.filter(Boolean)))

  if (uniqueIds.length === 0) {
    return new Map<string, Profile>()
  }

  const supabase = await createClient()
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .in('id', uniqueIds)

  if (error || !data) {
    return new Map<string, Profile>()
  }

  return new Map<string, Profile>(data.map((item) => [item.id, item]))
}

export async function getCurrentViewer() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return {
      user: null as User | null,
      profile: null as Profile | null,
    }
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  return {
    user,
    profile: profile ?? null,
  }
}

export async function getLatestVideos(limit = 20): Promise<VideoWithAuthor[]> {
  const supabase = await createClient()
  const { data: videos, error } = await supabase
    .from('videos')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit)

  if (error || !videos) {
    return []
  }

  const profilesMap = await getProfilesMap(videos.map((video) => video.user_id))

  return videos.map((video) => ({
    ...video,
    author: profilesMap.get(video.user_id) ?? null,
  }))
}

export async function getProfileByUsername(username: string) {
  const supabase = await createClient()
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('username', username)
    .maybeSingle()

  if (!profile) {
    return null
  }

  const { data: videos } = await supabase
    .from('videos')
    .select('*')
    .eq('user_id', profile.id)
    .order('created_at', { ascending: false })

  const resultVideos: VideoWithAuthor[] = (videos ?? []).map((video) => ({
    ...video,
    author: profile,
  }))

  return {
    profile,
    videos: resultVideos,
  }
}

export async function getAdminDashboardData() {
  const supabase = await createClient()

  const [{ data: profiles }, { data: videos }] = await Promise.all([
    supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50),
    supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(40),
  ])

  const profilesMap = await getProfilesMap((videos ?? []).map((video) => video.user_id))

  return {
    profiles: profiles ?? [],
    videos: (videos ?? []).map((video) => ({
      ...video,
      author: profilesMap.get(video.user_id) ?? null,
    })),
  }
}
