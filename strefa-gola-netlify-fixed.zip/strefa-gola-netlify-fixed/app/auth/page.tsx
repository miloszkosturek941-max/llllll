import { redirect } from 'next/navigation'

import { AuthForm } from '@/components/auth-form'
import { getCurrentViewer } from '@/lib/data'

export const dynamic = 'force-dynamic'

export default async function AuthPage() {
  const { user } = await getCurrentViewer()

  if (user) {
    redirect('/')
  }

  return (
    <div className="page-stack page-stack--narrow">
      <section className="hero hero--compact">
        <div>
          <p className="hero__eyebrow">Dołącz do społeczności</p>
          <h1>Zaloguj się albo załóż konto w Strefie Gola</h1>
          <p className="hero__text">
            Konto odblokowuje publikowanie klipów, lajki, komentarze, reposty i własny profil.
          </p>
        </div>
      </section>
      <AuthForm />
    </div>
  )
}
