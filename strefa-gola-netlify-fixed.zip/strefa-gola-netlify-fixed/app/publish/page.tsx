import { redirect } from 'next/navigation'

import { PublishForm } from '@/components/publish-form'
import { getCurrentViewer } from '@/lib/data'

export const dynamic = 'force-dynamic'

export default async function PublishPage() {
  const { user, profile } = await getCurrentViewer()

  if (!user || !profile) {
    redirect('/auth')
  }

  return (
    <div className="page-stack page-stack--narrow">
      <section className="hero hero--compact">
        <div>
          <p className="hero__eyebrow">Strefa twórców</p>
          <h1>Publikuj klipy z linku Google Drive</h1>
          <p className="hero__text">
            Feed pozostaje publiczny, ale publikowanie wymaga konta. Każdy klip trafi do głównej strefy filmów.
          </p>
        </div>
      </section>
      <PublishForm userId={user.id} />
    </div>
  )
}
