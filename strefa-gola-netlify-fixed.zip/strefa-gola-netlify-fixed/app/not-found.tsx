import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="page-stack page-stack--narrow">
      <section className="panel empty-state">
        <p className="panel__eyebrow">404</p>
        <h1>Nie znaleziono tej strony</h1>
        <p className="muted-text">Sprawdź adres albo wróć do głównego feedu Strefy Gola.</p>
        <Link href="/" className="primary-button">
          Wróć na start
        </Link>
      </section>
    </div>
  )
}
