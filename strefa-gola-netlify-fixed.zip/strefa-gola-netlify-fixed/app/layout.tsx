import type { ReactNode } from 'react'
import type { Metadata } from 'next'

import { SiteHeader } from '@/components/site-header'
import { getCurrentViewer } from '@/lib/data'

import './globals.css'

export const metadata: Metadata = {
  title: 'Strefa Gola',
  description: 'Polska aplikacja short-video w klimacie TikToka dla fanów futbolu.',
}

export default async function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  const { profile } = await getCurrentViewer()

  return (
    <html lang="pl">
      <body>
        <div className="page-frame">
          <SiteHeader profile={profile} />
          <main className="page-content">{children}</main>
        </div>
      </body>
    </html>
  )
}
