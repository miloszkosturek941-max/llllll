import Link from 'next/link'
import { notFound } from 'next/navigation'
import { BadgeCheck } from 'lucide-react'

import { VideoCard } from '@/components/video-card'
import { getCurrentViewer, getProfileByUsername } from '@/lib/data'

export const dynamic = 'force-dynamic'

interface ProfilePageProps {
  params: Promise<{
    username: string
  }>
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const { username } = await params
  const [{ user }, payload] = await Promise.all([getCurrentViewer(), getProfileByUsername(username)])

  if (!payload) {
    notFound()
  }

  const safePayload = payload
  const { profile, videos } = safePayload

  return (
    <div className="page-stack">
      <section className="profile-hero">
        <div>
          <p className="hero__eyebrow">profil publiczny</p>
          <div className="profile-hero__titleRow">
            <h1>{profile.display_name}</h1>
            {profile.is_verified ? <BadgeCheck className="verified-icon" size={22} /> : null}
          </div>
          <p className="hero__text">@{profile.username}</p>
          <p className="hero__text">{profile.bio || 'Ten użytkownik nie dodał jeszcze bio.'}</p>
        </div>
        <div className="hero__actions">
          <span className="info-chip">{videos.length} filmów</span>
          {user?.id === profile.id ? (
            <Link href="/publish" className="primary-button">
              Dodaj kolejny film
            </Link>
          ) : null}
        </div>
      </section>

      {videos.length === 0 ? (
        <section className="panel empty-state">
          <h2>Ten profil nie ma jeszcze żadnych filmów.</h2>
          <p className="muted-text">Wróć później albo zobacz główny feed.</p>
          <Link href="/" className="ghost-button ghost-button--accent">
            Przejdź do feedu
          </Link>
        </section>
      ) : (
        <section className="feed-stack">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} viewerId={user?.id ?? null} />
          ))}
        </section>
      )}
    </div>
  )
}
