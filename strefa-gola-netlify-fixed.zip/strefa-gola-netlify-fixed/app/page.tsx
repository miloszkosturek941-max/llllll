import Link from 'next/link'

import { VideoCard } from '@/components/video-card'
import { getCurrentViewer, getLatestVideos } from '@/lib/data'

export const dynamic = 'force-dynamic'

export default async function HomePage() {
  const [{ user }, videos] = await Promise.all([getCurrentViewer(), getLatestVideos(24)])

  return (
    <div className="page-stack">
      <section className="hero">
        <div>
          <p className="hero__eyebrow">feed otwarty dla wszystkich</p>
          <h1>Strefa Gola — futbolowe shorty, gole, reakcje i viralowe akcje.</h1>
          <p className="hero__text">
            Oglądanie działa bez logowania. Konto jest potrzebne dopiero wtedy, gdy chcesz publikować,
            lajkować, komentować albo robić reposty.
          </p>
        </div>
        <div className="hero__actions">
          <Link href="/publish" className="primary-button">
            Dodaj film
          </Link>
          <Link href="/auth" className="ghost-button ghost-button--accent">
            {user ? 'Zmień konto' : 'Załóż konto'}
          </Link>
        </div>
      </section>

      {videos.length === 0 ? (
        <section className="panel empty-state">
          <p className="panel__eyebrow">Na starcie</p>
          <h2>Jeszcze nie ma żadnych filmów</h2>
          <p className="muted-text">
            Dodaj pierwszy klip z Google Drive i uruchom feed Strefy Gola.
          </p>
          <Link href="/publish" className="primary-button">
            Opublikuj pierwszy film
          </Link>
        </section>
      ) : (
        <section className="feed-stack" aria-label="Główny feed filmów">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} viewerId={user?.id ?? null} />
          ))}
        </section>
      )}
    </div>
  )
}
