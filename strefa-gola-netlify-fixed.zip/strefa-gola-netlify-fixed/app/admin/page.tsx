import { redirect } from 'next/navigation'

import { AdminDashboard } from '@/components/admin-dashboard'
import { getAdminDashboardData, getCurrentViewer } from '@/lib/data'

export const dynamic = 'force-dynamic'

export default async function AdminPage() {
  const { profile } = await getCurrentViewer()

  if (!profile || profile.role !== 'admin') {
    redirect('/')
  }

  const data = await getAdminDashboardData()

  return (
    <div className="page-stack">
      <section className="hero hero--compact">
        <div>
          <p className="hero__eyebrow">Panel administratora</p>
          <h1>Moderacja filmów i weryfikacja kont</h1>
          <p className="hero__text">
            Konto admina ma możliwość usuwania cudzych filmów i nadawania weryfikacji — podobnie jak w klasycznych platformach short-video.
          </p>
        </div>
      </section>
      <AdminDashboard profiles={data.profiles} videos={data.videos} />
    </div>
  )
}
