# Strefa Gola — starter pod Netlify

Gotowy starter aplikacji short-video w stylu TikToka, ale pod marką **Strefa Gola**. Projekt jest przygotowany pod:

- **Next.js App Router**
- **Supabase Auth + PostgreSQL + RLS**
- **Netlify** jako hosting i deploy
- publikację filmów z **linków Google Drive**

## Co jest w środku

### Feed publiczny
- stronę główną może oglądać każdy, bez logowania
- feed pokazuje filmy, autora, lajki, komentarze i reposty
- klipy próbują odtwarzać się jako wideo, a jeśli Google Drive nie pozwoli na direct stream, przechodzą na `iframe` preview

### Auth
- rejestracja i logowanie przez Supabase email/hasło
- żeby publikować, lajkować, komentować i repostować trzeba być zalogowanym
- po rejestracji trigger w SQL tworzy profil automatycznie

### Admin
- konto `admin@strefagola.pl` dostaje rolę `admin` automatycznie po utworzeniu użytkownika w Supabase
- admin może:
  - usuwać cudze filmy
  - nadawać i cofać weryfikację użytkowników

### Profile
- publiczne profile użytkowników
- lista filmów przypisanych do danego autora

### Design
- kolorystyka oparta na przesłanym logo
- logo skopiowane do `public/logo.png`

## Struktura projektu

```text
strefa-gola-app/
├── app/
│   ├── admin/
│   ├── auth/
│   ├── profile/[username]/
│   ├── publish/
│   ├── globals.css
│   ├── layout.tsx
│   ├── not-found.tsx
│   └── page.tsx
├── components/
│   ├── admin-dashboard.tsx
│   ├── auth-controls.tsx
│   ├── auth-form.tsx
│   ├── publish-form.tsx
│   ├── site-header.tsx
│   └── video-card.tsx
├── lib/
│   ├── supabase/
│   │   ├── client.ts
│   │   ├── proxy.ts
│   │   └── server.ts
│   ├── data.ts
│   ├── database.types.ts
│   ├── google-drive.ts
│   ├── types.ts
│   └── utils.ts
├── public/
│   └── logo.png
├── supabase/
│   └── schema.sql
├── .env.example
├── netlify.toml
├── next.config.ts
├── package.json
├── proxy.ts
└── tsconfig.json
```

## 1. Supabase — konfiguracja bazy

Uruchom w Supabase SQL Editor cały plik:

- `supabase/schema.sql`

SQL tworzy:
- `profiles`
- `videos`
- `likes`
- `comments`
- `reposts`
- trigger tworzący profil po rejestracji
- trigger przypisujący rolę `admin` dla maila `admin@strefagola.pl`
- RLS dla publicznego feedu i prywatnych akcji

## 2. Utwórz konto admina

Po wykonaniu `schema.sql` załóż użytkownika w Supabase Auth:

- email: `admin@strefagola.pl`
- hasło: ustawiasz sam

Zrób to **po** odpaleniu SQL-a, żeby trigger od razu nadał rolę admina i weryfikację.

## 3. Zmienne środowiskowe

Skopiuj `.env.example` do `.env.local` lokalnie:

```bash
cp .env.example .env.local
```

Uzupełnij:

```env
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
```

## 4. Uruchomienie lokalne

```bash
npm install
npm run dev
```

## 5. Deploy na Netlify

Repo jest już przygotowane pod Netlify:

- plik `netlify.toml` ustawia build command i publish directory
- projekt używa `proxy.ts` do odświeżania sesji Supabase
- aplikacja nie potrzebuje osobnego backendu poza Supabase

### Najprostszy deploy

1. wrzuć projekt do GitHub / GitLab / Bitbucket
2. w Netlify wybierz **Add new project**
3. podepnij repo
4. ustaw environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
5. zrób deploy

Jeżeli Netlify nie wykryje ustawień automatycznie, użyj:

- Build command: `npm run build`
- Publish directory: `.next`

## 6. Publikowanie filmów z Google Drive

Użytkownik wkleja link w formacie podobnym do:

```text
https://drive.google.com/file/d/FILE_ID/view?usp=sharing
```

Aplikacja wyciąga `FILE_ID` i zapisuje:
- oryginalny link
- `drive_file_id`

Potem buduje:
- próbę bezpośredniego odtwarzania
- fallback do `preview` z Google Drive

### Ważne ustawienie pliku

Plik w Google Drive musi mieć:

- **Anyone with the link**
- rolę **Viewer**

Inaczej publiczny feed nie odtworzy materiału.

## Co jeszcze można dorobić później

- follow system
- DM / wiadomości prywatne
- zgłoszenia filmów
- hashatagi i wyszukiwarkę
- ranking trendujących filmów
- edycję profilu i avatarów
- panel admina do usuwania komentarzy

## Ważna uwaga

Nie wykonałem tutaj `npm install` ani produkcyjnego buildu w tym środowisku, więc potraktuj ten projekt jako **gotowy starter do wdrożenia**, a nie zweryfikowany deploy 1:1. Logika, routing, strukturę Netlify i integrację z Supabase przygotowałem, ale końcowe odpalenie trzeba zrobić po podpięciu prawdziwego projektu Supabase.
